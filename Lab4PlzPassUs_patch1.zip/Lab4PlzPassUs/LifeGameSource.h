#ifndef LIFEGAMESOURCE_H
#define LIFEGAMESOURCE_H
#include <string.h>
#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#pragma warning(disable: 4996)
#define BOARD_HEIGHT 20
#define BOARD_WIDTH 40
#define chrAlive '*'
#define chrDead '_'
#define uMinNeighborsToSurvive 2
#define uNeighborsToBeBorn 3
#define uMinNeighborsToOvercrowd 4

#endif