//-----------------------------------------------------------------------------
// Function: main
//
// Title: Game Of Life
//
// Description: 
//
// Programmer:	Brennan Freitas, Christopher Wong
//				John Muchinsky, Michael Guich
//
// Date: 2018-03-02
// Version: 0.1
//
// Environment:
//
// Input:
//
// Output:
//
// Called By:
//
// Calls:
//
// Parameters:
//
// Returns: 
//
// History Log:
//
//-----------------------------------------------------------------------------

#include "LifeGameSource.h"
int main(int argc, char *argv[])
{
	//set up variables and arrays
	int	board[MIN_BOARD_WIDTH][MIN_BOARD_HEIGHT];
	int i = 0;
	char input;
	char quit;
	initializeBoard(board);

	//output prompt
	printf("Welcome to the Game of Life!\n");
	printf("Please enter a (F)ile Name: \n");
	printf("\n");

	readFile(board, argc, argv[1]);

	print(board);
	do {
		input = _getche();
		system("cls");
		printf("To Exit Program Press X\n");
		switch (input)
		{
		case 'X':
		case 'x':
			system("cls");
			printf("\n\t\tthanks for playing \n\n");

			// Any character exits program
			quit = _getche();
			return(quit);
		default:
			break;
		}
		// Prints the board to the screen for user to view.
		play(board);
		print(board);

	} while (input != 'X', 'x');
}

//-----------------------------------------------------------------------------
// Function: initializeBoard
//
// Title: Game Of Life
//
// Description: 
//
// Programmer:	Brennan Freitas, Christopher Wong
//				John Muchinsky, Michael Guich
//
// Date: 2018-03-02
// Version: 0.1
//
// Environment:
//
// Input:
//
// Output:
//
// Called By:
//
// Calls:
//
// Parameters:
//
// Returns: 
//
// History Log:
//
//-----------------------------------------------------------------------------
void initializeBoard(int board[MIN_BOARD_WIDTH][MIN_BOARD_HEIGHT])
{
	// this will set the board to 0
	int x = 0;
	int y = 0;
	for (x = 0; x < MIN_BOARD_WIDTH; x++)
		for (y = 0; y < MIN_BOARD_HEIGHT; y++)
			board[x][y] = 0;
}

//-----------------------------------------------------------------------------
// Function: adjacentTo
//
// Title: Game Of Life
//
// Description: 
//
// Programmer:	Brennan Freitas, Christopher Wong
//				John Muchinsky, Michael Guich
//
// Date: 2018-03-02
// Version: 0.1
//
// Environment:
//
// Input:
//
// Output:
//
// Called By:
//
// Calls:
//
// Parameters:
//
// Returns: 
//
// History Log:
//
//-----------------------------------------------------------------------------
int adjacentTo(int board[MIN_BOARD_WIDTH][MIN_BOARD_HEIGHT], int x, int y)
{
	int i = 0;
	int j = 0;
	int count = 0;
	for (i = -1; i <= 1; i++)
		for (j = -1; j <= 1; j++)
			if (i || j)
				if (board[xadd(x, i)][yadd(y, j)]) count++;
	return count;
}

//-----------------------------------------------------------------------------
// Function: play
//
// Title: Game Of Life
//
// Description: 
//
// Programmer:	Brennan Freitas, Christopher Wong
//				John Muchinsky, Michael Guich
//
// Date: 2018-03-02
// Version: 0.1
//
// Environment:
//
// Input:
//
// Output:
//
// Called By:
//
// Calls:
//
// Parameters:
//
// Returns: 
//
// History Log:
//
//-----------------------------------------------------------------------------
void play(int board[MIN_BOARD_WIDTH][MIN_BOARD_HEIGHT])
{
	// This function determines which rule will be used.
	// for adjacent cells.
	int x = 0;
	int y = 0;
	int a = 0;
	char newboard[MIN_BOARD_WIDTH][MIN_BOARD_HEIGHT];
	for (x = 0; x < MIN_BOARD_WIDTH; x++)
		for (y = 0; y < MIN_BOARD_HEIGHT; y++)
		{
			a = adjacentTo(board, x, y);
			// if a is 2 then nothing dies or gives birth
			if (a == 2)
				newboard[x][y] = board[x][y];
			// if a is 2 then it gives birth to empty cell near it
			if (a == 3)
				newboard[x][y] = 1;
			// if a is < 2 OR > 3 then that cell dies 
			if (a < 2)
				newboard[x][y] = 0;
			if (a > 3)
				newboard[x][y] = 0;
		}
	// Copies the board back into the old board just used.
	for (x = 0; x < MIN_BOARD_WIDTH; x++)
		for (y = 0; y<MIN_BOARD_HEIGHT; y++)
		{
			board[x][y] = newboard[x][y];

		}
}

//-----------------------------------------------------------------------------
// Function: readFile
//
// Title: Game Of Life
//
// Description: 
//
// Programmer:	Brennan Freitas, Christopher Wong
//				John Muchinsky, Michael Guich
//
// Date: 2018-03-02
// Version: 0.1
//
// Environment:
//
// Input:
//
// Output:
//
// Called By:
//
// Calls:
//
// Parameters:
//
// Returns: 
//
// History Log:
//
//-----------------------------------------------------------------------------
void readFile(int board[MIN_BOARD_WIDTH][MIN_BOARD_HEIGHT], int argc, const char *argv)
{
	FILE * inFileHandle = NULL;
	int x = 0;
	int y = 0;
	char cell = ' ';
	char strFileName[FILENAME_MAX];

	if (argc > 1)
	{
		strncpy(strFileName, argv, FILENAME_MAX);
	}
	else
	{
		fgets(strFileName, FILENAME_MAX, stdin);
		if (strFileName[strlen(strFileName) - 1] == '\n')
			strFileName[strlen(strFileName) - 1] = '\0';
		else
			while (getchar() != '\n');
	}
	// Opens file in read mode.
	inFileHandle = fopen(strFileName, "r");


	for (y = 0; y < MIN_BOARD_HEIGHT; y++)
	{
		for (x = 0; x < MIN_BOARD_WIDTH; x++)
		{
			cell = getc(inFileHandle);
			board[x][y] = (cell == '*');
		}//getc(inFileHandle);

	}
	fclose(inFileHandle);
}

//-----------------------------------------------------------------------------
// Function: xadd
//
// Title: Game Of Life
//
// Description: 
//
// Programmer:	Brennan Freitas, Christopher Wong
//				John Muchinsky, Michael Guich
//
// Date: 2018-03-02
// Version: 0.1
//
// Environment:
//
// Input:
//
// Output:
//
// Called By:
//
// Calls:
//
// Parameters:
//
// Returns: 
//
// History Log:
//
//-----------------------------------------------------------------------------
int xadd(int x, int a)
{
	// adds width to the board
	x += a;
	while (x < 0)
		x += MIN_BOARD_WIDTH;
	while (x >= MIN_BOARD_WIDTH) x -= MIN_BOARD_WIDTH;
	return x;
}

//-----------------------------------------------------------------------------
// Function: yadd
//
// Title: Game Of Life
//
// Description: 
//
// Programmer:	Brennan Freitas, Christopher Wong
//				John Muchinsky, Michael Guich
//
// Date: 2018-03-02
// Version: 0.1
//
// Environment:
//
// Input:
//
// Output:
//
// Called By:
//
// Calls:
//
// Parameters:
//
// Returns: 
//
// History Log:
//
//-----------------------------------------------------------------------------
int yadd(int y, int a)
{
	// adds height to the board
	y += a;
	while (y < 0)
		y += MIN_BOARD_HEIGHT;
	while (y >= MIN_BOARD_HEIGHT) y -= MIN_BOARD_HEIGHT;
	return y;
}

//-----------------------------------------------------------------------------
// Function: print
//
// Title: Game Of Life
//
// Description: 
//
// Programmer:	Brennan Freitas, Christopher Wong
//				John Muchinsky, Michael Guich
//
// Date: 2018-03-02
// Version: 0.1
//
// Environment:
//
// Input:
//
// Output:
//
// Called By:
//
// Calls:
//
// Parameters:
//
// Returns: 
//
// History Log:
//
//-----------------------------------------------------------------------------
void print(int board[MIN_BOARD_WIDTH][MIN_BOARD_HEIGHT])
{
	// Prints the board, x being the living, ' ' being nonexistent
	int x = 0;
	int y = 0;
	for (y = 0; y < MIN_BOARD_HEIGHT; y++)
	{
		for (x = 0; x < MIN_BOARD_WIDTH; x++)
		{
			putchar(board[x][y] ? 'x' : ' ');
		}
		putchar('\n');
	}
}
