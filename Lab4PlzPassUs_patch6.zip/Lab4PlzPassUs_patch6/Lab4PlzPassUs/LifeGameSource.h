#ifndef TGOLSOURCE_H
#define TGOLSOURCE_H
#include <string.h>
#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#define MIN_BOARD_HEIGHT 20
#define MIN_BOARD_WIDTH 40
#pragma warning(disable: 4996)
void initializeBoard(int board[MIN_BOARD_WIDTH][MIN_BOARD_HEIGHT]);
int xadd(int x, int a);
int yadd(int x, int a);
int adjacentTo(int board[MIN_BOARD_WIDTH][MIN_BOARD_HEIGHT], int x, int y);
void readFile(int board[MIN_BOARD_WIDTH][MIN_BOARD_HEIGHT], int argc, const char *argv);
void print(int board[MIN_BOARD_WIDTH][MIN_BOARD_HEIGHT]);
void play(int board[MIN_BOARD_WIDTH][MIN_BOARD_HEIGHT]);
#endif