//----------------------------------------------------------------------------
// File			: MainGameOfLife.c
//
// Functions	: int main(int argc, char *argv[])			  
//----------------------------------------------------------------------------
#include "LifeGameSource.h"
//-----------------------------------------------------------------------------
// Function: main()
//
// Title: Game Of Life
//
// Description: It runs the Game of Life:
//				By the rules of the game, individuals require others to survive, 
//				but die as the result of overcrowding.
//				Birth Rule: an organism is born into an empty cell that has 
//							exactly three living neighbors.
//				Survival Rule : An organism survives from one generation to the 
//								next if it has either 2 or 3 living neighbor.
//				Death Rule : An organism dies from loneliness if it has fewer 
//							 than 2 neighbors.It dies from overcrowding if it 
//							 has 4 or more neighbors.
//
// Programmer:	Brennan Freitas, Christopher Wong
//				John Muchinsky, Michael Guich
//
// Date: 2018-03-02
// Version: 0.1
//
// Environment:
//
// Input: The file name of the text file including starting organisms.
//
// Output: It shows next generations of the world.
//
// Called By:
//
// Calls: initializedBoard(), readFile()
//		  print(), play()
//
// Parameters: int argc, char *argv[]
//
// Returns: quit
//
// History Log:
//
//-----------------------------------------------------------------------------

int main(int argc, char *argv[])
{
	//set up variables and arrays
	int	board[MIN_BOARD_WIDTH][MIN_BOARD_HEIGHT];
	int i = 0;
	char input;
	char quit;
	initializeBoard(board);

	//output prompt
	printf("Welcome to the Game of Life!\n");
	printf("Please enter a (F)ile Name: \n");
	printf("\n");

	readFile(board, argc, argv[1]);

	print(board);
	do {
		input = _getche();
		system("cls");
		printf("To Exit Program Press X\n");
		switch (input)
		{
		case 'X':
		case 'x':
			system("cls");
			printf("\n\t\tthanks for playing \n\n");

			// Any character exits program
			quit = _getche();
			return(quit);
		default:
			break;
		}
		// Prints the board to the screen for user to view.
		play(board);
		print(board);

	} while (input != 'X', 'x');
}


