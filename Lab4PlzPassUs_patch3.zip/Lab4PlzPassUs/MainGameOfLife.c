//----------------------------------------------------------------------
// File: Lab4PlzPassUs
//
// Functions: main, countNeighbors, die, copyState, born
//----------------------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <conio.h>
#include "LifeGameSource.h"
#pragma warning(disable: 4996)


//----------------------------------------------------------------------
// Function: 
//
// Title: Game Of Life
//
// Description: 
//
// Programmer:	Brennan Freitas, Christopher Wong
//				John Muchinsky, Michael Guich
//
// Date: 2018-03-02
// Version: 0.1
//
// Environment:
//
// Input:
//
// Output:
//
// Called By:
//
// Calls:
//
// Parameters:
//
// Returns: 
//
// History Log:
//
//----------------------------------------------------------------------

int main(int argc, char* argv[]) 
{
	//set up variables and arrays
	char* chrWorld[2][BOARD_HEIGHT][BOARD_WIDTH] = { {'\0'} };
	unsigned uPosX = 0u;
	unsigned uPosY = 0u;
	unsigned uNeighbors = 0u;
	unsigned uArrayNextGen = 0u;
	unsigned width = BOARD_WIDTH;
	unsigned height = BOARD_HEIGHT;
	int* returnValue = EXIT_SUCCESS;
	bool lever = true;
	
	//read file into array
	getGameBoard(chrWorld,width,height,argc,argv,returnValue);
	getchar();		//wait for input

	//While(not quiting)
	while(lever == true) 
	{
		//For(each collumn)
		for (uPosX = 0; uPosX < width; uPosX++) 
		{
			//For(each cell)
			for (uPosY = 0; uPosY < height; uPosY++)
			{
				//count neighbors
				if (uArrayNextGen == 0)
				{
					uNeighbors = countNeighbors(chrWorld, 1u, uPosX, uPosY);
				}
				else
				{
					uNeighbors = countNeighbors(chrWorld, 0u, uPosX, uPosY);
				}

				//fill next world
				if ((uNeighbors < uMinNeighborsToSurvive) || 
					(uNeighbors >= uMinNeighborsToOvercrowd)) 
				{
					//die
					die(chrWorld, uArrayNextGen, uPosX, uPosY);
				}
				else if (uNeighbors == uNeighborsToBeBorn) 
				{
					//born
					born(chrWorld, uArrayNextGen, uPosX, uPosY);
				}
				else
				{ //not dying or being born
					//copy state
					copyState(chrWorld, uArrayNextGen, uPosX, uPosY);
				}

			} //end For(each cell)
		} //end For(each collum)

		//clear console

		//output header

		//output the new array
		for (uPosY = 0; uPosY < height; uPosY++) {
			for (uPosX = 0; uPosX < width; uPosX++) {
				printf(chrWorld[uArrayNextGen][uPosX][uPosY]);
			}
			printf("\n");
		}

		//swap array roles
		if (uArrayNextGen == 0) 
		{
			uArrayNextGen = 1;
		} 
		else 
		{
			uArrayNextGen = 0;
		}

	} //end While(not quitting)

	//say goodby
	return returnValue;
}

//----------------------------------------------------------------------
// Function: countNeighbors
//
// Title: Game Of Life
//
// Description: 
//
// Programmer:	Brennan Freitas, Christopher Wong
//				John Muchinsky, Michael Guich
//
// Date: 2018-03-02
// Version: 0.1
//
// Environment:
//
// Input:
//
// Output:
//
// Called By:
//
// Calls:
//
// Parameters:
//
// Returns: 
//
// History Log:
//
//----------------------------------------------------------------------

unsigned countNeighbors(char* chrWorld[][BOARD_HEIGHT][BOARD_WIDTH], unsigned uArrayInUse, 
						unsigned uPosX, unsigned uPosY) {

	unsigned uNeightbors = 0u;
	int i = 0;

	//count lower row neighbors
	for (i = -1; i <= 1; i++) {
		if (chrWorld[uArrayInUse][uPosX + i][uPosY - 1] = chrAlive) {
			uNeightbors++;
		}
	}

	//count same row neighbors
	if (chrWorld[uArrayInUse][uPosX - 1][uPosY] = chrAlive) {
		uNeightbors++;
	}
	if (chrWorld[uArrayInUse][uPosX + 1][uPosY] = chrAlive) {
		uNeightbors++;
	}

	//count upper row neighbors
	for (i = -1; i <= 1; i++) {
		if (chrWorld[uArrayInUse][uPosX + i][uPosY + 1] = chrAlive)
		{
			uNeightbors++;
		}
	}

	return uNeightbors;
}

//----------------------------------------------------------------------
// Function: die
//
// Title: Game Of Life
//
// Description: 
//
// Programmer:	Brennan Freitas, Christopher Wong
//				John Muchinsky, Michael Guich
//
// Date: 2018-03-02
// Version: 0.1
//
// Environment:
//
// Input:
//
// Output:
//
// Called By:
//
// Calls:
//
// Parameters:
//
// Returns: 
//
// History Log:
//
//----------------------------------------------------------------------

void die(char* chrWorld[][BOARD_HEIGHT][BOARD_WIDTH], unsigned uArrayNextGen, unsigned uPosX, unsigned uPosY) {
	chrWorld[uArrayNextGen][uPosX][uPosY] = chrDead;
}

//----------------------------------------------------------------------
// Function: copyState
//
// Title: Game Of Life
//
// Description: 
//
// Programmer:	Brennan Freitas, Christopher Wong
//				John Muchinsky, Michael Guich
//
// Date: 2018-03-02
// Version: 0.1
//
// Environment:
//
// Input:
//
// Output:
//
// Called By:
//
// Calls:
//
// Parameters:
//
// Returns: 
//
// History Log:
//
//----------------------------------------------------------------------

void copyState(char* chrWorld[][BOARD_HEIGHT][BOARD_WIDTH], unsigned uArrayNextGen, unsigned uPosX, unsigned uPosY) {
	//set value in next world to value in this one
	if (uArrayNextGen = 0) {
		chrWorld[0][uPosX][uPosY] = chrWorld[1][uPosX][uPosY];
	} 
	else 
	{
		chrWorld[1][uPosX][uPosY] = chrWorld[0][uPosX][uPosY];
	}
}

//----------------------------------------------------------------------
// Function: born
//
// Title: Game Of Life
//
// Description: 
//
// Programmer:	Brennan Freitas, Christopher Wong
//				John Muchinsky, Michael Guich
//
// Date: 2018-03-02
// Version: 0.1
//
// Environment:
//
// Input:
//
// Output:
//
// Called By:
//
// Calls:
//
// Parameters:
//
// Returns: 
//
// History Log:
//
//----------------------------------------------------------------------

void born(char* chrWorld[][BOARD_HEIGHT][BOARD_WIDTH], unsigned uArrayNextGen, unsigned uPosX, unsigned uPosY) {
	chrWorld[uArrayNextGen][uPosX][uPosY] = chrAlive;
}

void getGameBoard(char* chrWorld[][BOARD_HEIGHT][BOARD_WIDTH], unsigned width, unsigned height, int argc, char* argv[], int* returnValue) 
{
	FILE* inFile = NULL;
	char filename[FILENAME_MAX] = "";
	char tempLine[] = "";
	if (argc > 1)
	{
		strncpy(filename, argv[1], FILENAME_MAX);
	}
	else
	{
		printf("Enter the name of the file to read: ");
		fgets(filename, FILENAME_MAX, stdin);
		if (filename[strlen(filename) - 1] == '\n')
			filename[strlen(filename) - 1] = '\0';
		else
			while (getchar() != '\n')
				;
	}
	inFile = fopen(filename, "r");
	if (inFile == NULL)
	{
		printf("\nCould not open file %s for input.\n", filename);
		puts("\nPress any key to Continue");
		getch();
		*returnValue = EXIT_FAILURE;
	}
	else 
	{
		for (unsigned i = 0u; i < height; i++) 
		{
			for (unsigned j = 0u; j < width; j++) 
			{
				chrWorld[1][i][j] = fgetc(inFile);
			}
			fgetc(inFile);
		}
	}
}