//----------------------------------------------------------------------------
// File			: GameOfLife.h
//
// Functions	:	unsigned countNeighbors(char *chrWorld, unsigned uArrayInUse, unsigned uPosX, unsigned uPosY)
//					void die(char *chrWorld, unsigned uArrayNextGen, unsigned uPosX, unsigned uPosY)
//					void copyState(char *chrWorld, unsigned uArrayNextGen, unsigned uPosX, unsigned uPosY)
//					void born(char *chrWorld, unsigned uArrayNextGen, unsigned uPosX, unsigned uPosY)
//----------------------------------------------------------------------------
#ifndef GAMEOFLIFE_H
#define GAMEOFLIFE_H
#pragma warning(disable : 4996)

unsigned countNeighbors(char *chrWorld, unsigned uArrayInUse, unsigned uPosX, unsigned uPosY);
void die(char *chrWorld, unsigned uArrayNextGen, unsigned uPosX, unsigned uPosY);
void copyState(char *chrWorld, unsigned uArrayNextGen, unsigned uPosX, unsigned uPosY);
void born(char *chrWorld, unsigned uArrayNextGen, unsigned uPosX, unsigned uPosY);

#endif
