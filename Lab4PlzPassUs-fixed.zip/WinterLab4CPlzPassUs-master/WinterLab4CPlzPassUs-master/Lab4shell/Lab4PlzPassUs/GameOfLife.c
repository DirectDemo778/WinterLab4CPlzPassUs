//----------------------------------------------------------------------------
// File			: GameOfLife.c
//
// Functions	:	unsigned countNeighbors(char *chrWorld, unsigned uArrayInUse, unsigned uPosX, unsigned uPosY)
//					void die(char *chrWorld, unsigned uArrayNextGen, unsigned uPosX, unsigned uPosY)
//					void copyState(char *chrWorld, unsigned uArrayNextGen, unsigned uPosX, unsigned uPosY)
//					void born(char *chrWorld, unsigned uArrayNextGen, unsigned uPosX, unsigned uPosY)
//----------------------------------------------------------------------------
#include "GameOfLife.h"
#define ALIVE  '*'
#define DEAD  '_'
#define SURVIVE  2
#define BORN  3
#define OVERCROWD  4
//----------------------------------------------------------------------
// Function: countNeighbors
//
// Title: Game Of Life
//
// Description: 
//
// Programmer:	Brennan Freitas, Christopher Wong
//				John Muchinsky, Michael Guich
//
// Date: 2018-03-02
// Version: 0.1
//
// Environment:
//
// Input:
//
// Output:
//
// Called By:
//
// Calls:
//
// Parameters:
//
// Returns: 
//
// History Log:
//
//----------------------------------------------------------------------

unsigned countNeighbors(char *chrWorld, unsigned uArrayInUse,
	unsigned uPosX, unsigned uPosY)
{

	unsigned uNeightbors = 0;
	int i = 0;

	//count lower row neighbors
	for (i = -1; i <= 1; i++)
	{
		if (chrWorld[uArrayInUse, uPosX + i, uPosY - 1] == ALIVE)
		{
			uNeightbors++;
		}
	}

	//count same row neighbors
	if (chrWorld[uArrayInUse, uPosX - 1, uPosY] == ALIVE)
	{
		uNeightbors++;
	}
	if (chrWorld[uArrayInUse, uPosX + 1, uPosY] == ALIVE)
	{
		uNeightbors++;
	}

	//count upper row neighbors
	for (i = -1; i <= 1; i++)
	{
		if (chrWorld[uArrayInUse, uPosX + i, uPosY + 1] == ALIVE)
		{
			uNeightbors++;
		}
	}

	return uNeightbors;
}

//----------------------------------------------------------------------
// Function: die
//
// Title: Game Of Life
//
// Description: 
//
// Programmer:	Brennan Freitas, Christopher Wong
//				John Muchinsky, Michael Guich
//
// Date: 2018-03-02
// Version: 0.1
//
// Environment:
//
// Input:
//
// Output:
//
// Called By:
//
// Calls:
//
// Parameters:
//
// Returns: 
//
// History Log:
//
//----------------------------------------------------------------------

void die(char *chrWorld, unsigned uArrayNextGen, unsigned uPosX, unsigned uPosY)
{
	chrWorld[uArrayNextGen, uPosX, uPosY] = DEAD;
}

//----------------------------------------------------------------------
// Function: copyState
//
// Title: Game Of Life
//
// Description: 
//
// Programmer:	Brennan Freitas, Christopher Wong
//				John Muchinsky, Michael Guich
//
// Date: 2018-03-02
// Version: 0.1
//
// Environment:
//
// Input:
//
// Output:
//
// Called By:
//
// Calls:
//
// Parameters:
//
// Returns: 
//
// History Log:
//
//----------------------------------------------------------------------

void copyState(char *chrWorld, unsigned uArrayNextGen, unsigned uPosX, unsigned uPosY) {
	//set value in next world to value in this one
	if (uArrayNextGen == 0)
	{
		chrWorld[0, uPosX, uPosY] = chrWorld[1, uPosX, uPosY];
	}
	else
	{
		chrWorld[1, uPosX, uPosY] = chrWorld[0, uPosX, uPosY];
	}
}

//----------------------------------------------------------------------
// Function: born
//
// Title: Game Of Life
//
// Description: 
//
// Programmer:	Brennan Freitas, Christopher Wong
//				John Muchinsky, Michael Guich
//
// Date: 2018-03-02
// Version: 0.1
//
// Environment:
//
// Input:
//
// Output:
//
// Called By:
//
// Calls:
//
// Parameters:
//
// Returns: 
//
// History Log:
//
//----------------------------------------------------------------------

void born(char *chrWorld, unsigned uArrayNextGen, unsigned uPosX, unsigned uPosY)
{
	chrWorld[uArrayNextGen, uPosX, uPosY] = ALIVE;
}