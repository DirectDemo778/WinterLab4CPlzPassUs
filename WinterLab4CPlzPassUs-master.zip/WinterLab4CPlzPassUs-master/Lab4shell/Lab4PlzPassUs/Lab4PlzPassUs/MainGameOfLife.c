//----------------------------------------------------------------------
// File: Lab4PlzPassUs
//
// Functions: main, countNeighbors, die, copyState, born
//----------------------------------------------------------------------

#define chrAlive = '*'
#define chrDead = '_'
#define uMinNeighborsToSurvive = 2
#define uNeighborsToBeBorn = 3
#define uMinNeighborsToOvercrowd = 4

//----------------------------------------------------------------------
// Function: 
//
// Title: Game Of Life
//
// Description: 
//
// Programmer:	Brennan Freitas, Christopher Wong
//				John Muchinsky, Michael Guich
//
// Date: 2018-03-02
// Version: 0.1
//
// Environment:
//
// Input:
//
// Output:
//
// Called By:
//
// Calls:
//
// Parameters:
//
// Returns: 
//
// History Log:
//
//----------------------------------------------------------------------

int main(void) 
{
	//set up variables and arrays
	char chrWorld*;
	unsigned uPosX = 0;
	unsigned uPosY = 0;
	unsigned uNeighbors = 0;
	unsigned uArrayNextGen = 0;

	//read file into array

	getchar();		//wait for input

	//While(not quiting)
	While() {
		//For(each collumn)
		for (uPosX = 0; uPosX < /*array width*/; uPosX++) {
			//For(each cell)
			for (uPosY = 0; uPosY < /*array width*/; uPosY++) {
				//count neighbors
				if (uArrayNextGen = 0) {
					uNeighbors = countNeighbors(chrWorld, 1, uPosX, uPosY);
				}
				else {
					uNeighbors = countNeighbors(chrWorld, 0, uPosX, uPosY);
				}

				//fill next world
				if (uNeighbors < uMinNeighborsToSurvive || 
					uNeighbors >= uMinNeighborsToOvercrowd) {
					//die
					die(chrWorld, uArrayNextGen, uPosX, uPosY);
				}
				else if (uNeighbors = uNeighborsToBeBorn) {
					//born
					born(chrWorld, uArrayNextGen, uPosX, uPosY);
				}
				else { //not dying or being born
					//copy state
					copyState(chrWorld, uArrayNextGen, uPosX, uPosY);
				}

			} //end For(each cell)
		} //end For(each collum)

		//clear console

		//output header

		//output the new array
		for (uPosY = 0; uPosY < /*array width*/; uPosY++) {
			for (uPosX = 0; uPosX < /*array width*/; uPosX++) {
				printf(chrWorld[uArrayNextGen, uPosX, uPosY]);
			}
			printf('\n');
		}

		//swap array roles
		if (uArrayNextGen = 0) {
			uArrayNextGen = 1
		} else {
			uArrayNextGen = 0
		}

	} //end While(not quitting)

	//say goodby

}

//----------------------------------------------------------------------
// Function: countNeighbors
//
// Title: Game Of Life
//
// Description: 
//
// Programmer:	Brennan Freitas, Christopher Wong
//				John Muchinsky, Michael Guich
//
// Date: 2018-03-02
// Version: 0.1
//
// Environment:
//
// Input:
//
// Output:
//
// Called By:
//
// Calls:
//
// Parameters:
//
// Returns: 
//
// History Log:
//
//----------------------------------------------------------------------

unsigned countNeighbors(char chrWorld*, unsigned uArrayInUse, 
						unsigned uPosX, unsigned uPosY) {

	unsigned uNeightbors = 0;
	int i = 0;

	//count lower row neighbors
	for (i = -1; i <= 1; i++) {
		if (chrWorld[uArrayInUse, uPosX + i, uPosY - 1] = chrAlive) {
			uNeightbors++;
		}
	}

	//count same row neighbors
	if (chrWorld[uArrayInUse, uPosX - 1, uPosY] = chrAlive) {
		uNeightbors++;
	}
	if (chrWorld[uArrayInUse, uPosX + 1, uPosY] = chrAlive) {
		uNeightbors++;
	}

	//count upper row neighbors
	for (i = -1; i <= 1; i++) {
		if (chrWorld[uArrayInUse, uPosX + i, uPosY + 1] = chrAlive) {
			uNeightbors++;
		}
	}

	return uNeightbors;
}

//----------------------------------------------------------------------
// Function: die
//
// Title: Game Of Life
//
// Description: 
//
// Programmer:	Brennan Freitas, Christopher Wong
//				John Muchinsky, Michael Guich
//
// Date: 2018-03-02
// Version: 0.1
//
// Environment:
//
// Input:
//
// Output:
//
// Called By:
//
// Calls:
//
// Parameters:
//
// Returns: 
//
// History Log:
//
//----------------------------------------------------------------------

void die(char chrWorld*, unsigned uArrayNextGen, unsigned uPosX, unsigned uPosY) {
	chrWorld[uArrayNextGen, uPosX, uPosY] = chrDead;
}

//----------------------------------------------------------------------
// Function: copyState
//
// Title: Game Of Life
//
// Description: 
//
// Programmer:	Brennan Freitas, Christopher Wong
//				John Muchinsky, Michael Guich
//
// Date: 2018-03-02
// Version: 0.1
//
// Environment:
//
// Input:
//
// Output:
//
// Called By:
//
// Calls:
//
// Parameters:
//
// Returns: 
//
// History Log:
//
//----------------------------------------------------------------------

void copyState(char chrWorld*, unsigned uArrayNextGen, unsigned uPosX, unsigned uPosY) {
	//set value in next world to value in this one
	if (uArrayNextGen = 0) {
		chrWorld[0, uPosX, uPosY] = chrWorld[1, uPosX, uPosY]
	} else {
		chrWorld[1, uPosX, uPosY] = chrWorld[0, uPosX, uPosY]
	}
}

//----------------------------------------------------------------------
// Function: born
//
// Title: Game Of Life
//
// Description: 
//
// Programmer:	Brennan Freitas, Christopher Wong
//				John Muchinsky, Michael Guich
//
// Date: 2018-03-02
// Version: 0.1
//
// Environment:
//
// Input:
//
// Output:
//
// Called By:
//
// Calls:
//
// Parameters:
//
// Returns: 
//
// History Log:
//
//----------------------------------------------------------------------

void born(char chrWorld*, unsigned uArrayNextGen, unsigned uPosX, unsigned uPosY) {
	chrWorld[uArrayNextGen, uPosX, uPosY] = chrAlive;
}