//----------------------------------------------------------------------
// File: Lab4PlzPassUs
//
// Functions: main, countNeighbors, die, copyState, born
//----------------------------------------------------------------------
#include "GameOfLife.h"
//----------------------------------------------------------------------
// Function: 
//
// Title: Game Of Life
//
// Description: 
//
// Programmer:	Brennan Freitas, Christopher Wong
//				John Muchinsky, Michael Guich
//
// Date: 2018-03-02
// Version: 0.1
//
// Environment:
//
// Input:
//
// Output:
//
// Called By:
//
// Calls:
//
// Parameters:
//
// Returns: 
//
// History Log:
//
//----------------------------------------------------------------------

int main(void) 
{
	//set up variables and arrays
	char chrWorld;
	unsigned uPosX = 0;
	unsigned uPosY = 0;
	unsigned uNeighbors = 0;
	unsigned uArrayNextGen = 0;

	//read file into array

	getchar();		//wait for input

	//While(not quiting)
	While() 
	{
		//For(each collumn)
		for (uPosX = 0; uPosX < /*array width*/; uPosX++) 
		{
			//For(each cell)
			for (uPosY = 0; uPosY < /*array width*/; uPosY++) 
			{
				//count neighbors
				if (uArrayNextGen == 0) 
				{
					uNeighbors = countNeighbors(chrWorld, 1, uPosX, uPosY);
				}
				else 
				{
					uNeighbors = countNeighbors(chrWorld, 0, uPosX, uPosY);
				}

				//fill next world
				if (uNeighbors < uMinNeighborsToSurvive || 
					uNeighbors >= uMinNeighborsToOvercrowd) 
				{
					//die
					die(chrWorld, uArrayNextGen, uPosX, uPosY);
				}
				else if (uNeighbors == uNeighborsToBeBorn) 
				{
					//born
					born(chrWorld, uArrayNextGen, uPosX, uPosY);
				}
				else 
				{ //not dying or being born
					//copy state
					copyState(chrWorld, uArrayNextGen, uPosX, uPosY);
				}

			} //end For(each cell)
		} //end For(each collum)

		//clear console

		//output header

		//output the new array
		for (uPosY = 0; uPosY < /*array width*/; uPosY++) 
		{
			for (uPosX = 0; uPosX < /*array width*/; uPosX++) 
			{
				printf(chrWorld[uArrayNextGen, uPosX, uPosY]);
			}
			printf('\n');
		}

		//swap array roles
		if (uArrayNextGen == 0) 
		{
			uArrayNextGen = 1;
		} 
		else 
		{
			uArrayNextGen = 0;
		}

	} //end While(not quitting)

	//say goodby

	return EXIT_SUCCESS;
}

